﻿var people = new List<Person>();
var a = people.Where(x=> x.Age>20).OrderBy(x=> x.Name).ToList();
var b = people.Where(x=> x.BirthDate<new DateTime(1999,1,1)).ToList();
//var c = people.Where(x=>x.BirthDate)
var d = people.OrderBy(x=>x.Id).ToList()[3];
var e = people.OrderBy(x=>x.Id).ToList().Take(new Range(50,80));
var f = people.Where(x=> x.Age==people.Max(y=> y.Age)).ToList();
var g = people.GroupBy(x=> x.SSID);
var h = people.Where(x=> x.Address.Contains("Tehran")).ToList();
//var i = h.Where(x=>x.Name==) 
var j = people.Where(x=> x.Age.ToString().Contains("1233")).ToList();
var k = people.Where(x=>x.Age>25).ToList().Select(x=> new {x.Address,x.SSID}).ToList();