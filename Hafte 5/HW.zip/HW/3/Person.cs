public class Person
{
    public int Id { get; set; }
    public string Name { get; set; }
    public DateTime BirthDate { get; set; }
    public int SSID { get; set; }
    public int Age { get; set; }
    public string Address { get; set; }     
}
