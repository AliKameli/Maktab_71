﻿var sourceFilePath = "file.txt";
var endFilePath = "Archive/" + sourceFilePath;
try
{
    File.Copy(sourceFilePath, endFilePath);
}
catch (FileNotFoundException _)
{
    Console.WriteLine("File Peyda Nashod");
}
catch (DirectoryNotFoundException _)
{
    Console.WriteLine("Poshe Maghsad Vojood nadarad");
}
catch (IOException _)
{
    Console.WriteLine("file vojood dashte");
}
catch (Exception e)
{
    Console.WriteLine(e);
}
Console.ReadKey();